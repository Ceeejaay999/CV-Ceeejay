// Portfolio uses vanilla HTML/CSS/JS in index.html
export default function App() {
  return null;
}
