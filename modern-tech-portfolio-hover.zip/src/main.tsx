// Portfolio is rendered directly in index.html with vanilla JS
